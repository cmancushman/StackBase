//
//  StackBaseNumericType.h
//  Park It
//
//  Created by Chris Cushman on 9/18/17.
//  Copyright © 2017 Ubord, Inc. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface StackBaseNumericType : NSString

@end
