//
//  StackBaseColumnDateTimeType.h
//  StackBase
//
//  Created by Chris Cushman on 11/2/17.
//  Copyright © 2017 Chris Cushman. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface StackBaseDateTimeType : NSString

@end
